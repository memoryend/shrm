$(function(){
	$("#main_slider").bxSlider({
		auto:true,
		responsive:false
	});
});